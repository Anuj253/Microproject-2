const app = Vue.createApp({
    data() {
        return {
            pageTitle: "Order Your Subway Sandwich",
            orderText: "Customize your sandwich and place your order.",
        };
    },
    methods: {
        placeOrder() {
            alert('Order placed!');
        },
        goToSubway() {
            window.location.href = 'https://www.subway.com';
        }
    }
});
app.mount('#app');
